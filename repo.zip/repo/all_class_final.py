import pygame, random, math, time
from pygame.locals import *
pygame.init()
j = round(70*math.sqrt(2))
class Ball_oneplayer:
    def __init__(self,radius,x,y,screen,right,priv):
        self.radius  = radius
        self.screen_width = screen.get_width()
        self.screen_height = screen.get_height()
        self.screen = screen
        self.raw_image = pygame.image.load('./ball.png').convert()
        self.image = pygame.transform.scale(self.raw_image,(radius,radius))
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y
        self.image.set_colorkey((0,0,0))
        if priv:
            self.xspeed = -2
        else:
            self.xspeed = 2
        self.yspeed = random.choice([-2,-1.5,-1,1,1.5,2])
        self.right = right
        self.running = True
    def bounce(self):
        global running
        b = round(10*math.sqrt(2))
        if self.xspeed > 0:
            if self.right.rotate_state == 1:
                if (self.screen_width-3*b < self.rect.centerx < self.screen_width) and (self.right.y < self.rect.centery < self.right.y+self.right.length):
                    hit = pygame.mixer.Sound('ball_hit.wav')
                    hit.play()
                    temp = self.xspeed
                    self.xspeed = self.yspeed
                    self.yspeed = temp
                    return 2
            elif self.right.rotate_state == -1:
                if (self.screen_width-3*b < self.rect.centerx < self.screen_width) and (self.right.y < self.rect.centery < self.right.y+self.right.length):
                    hit = pygame.mixer.Sound('ball_hit.wav')
                    hit.play()
                    temp = self.xspeed
                    self.xspeed = -self.yspeed
                    self.yspeed = -temp
                    return 2
            else:
                if self.rect.right >= self.screen_width-20:
                    if self.rect.centery > self.right.y and self.rect.centery < self.right.y+self.right.length:
                        hit = pygame.mixer.Sound('ball_hit.wav')
                        hit.play()
                        self.xspeed = -self.xspeed 
                        return 2
                    if self.rect.right >= self.screen_width:
                        self.running = False
                        return 1
        if self.xspeed < 0:
            if self.rect.left <= 0:
                self.xspeed = -self.xspeed
        if self.rect.bottom >= self.screen_height or self.rect.top <= 0:
            self.yspeed = - self.yspeed
    def update(self):
        self.rect.move_ip(self.xspeed,self.yspeed) #移動 method -- move_ip()
        a = self.bounce() # 碰邊則反彈
        self.screen.blit(self.image,self.rect) #重畫
        return a
class Ball_twoplayers:
    def __init__(self,radius,x,y,screen,left,right,priv):
        self.radius  = radius
        self.screen_width = screen.get_width()
        self.screen_height = screen.get_height()
        self.screen = screen
        self.raw_image = pygame.image.load('./ball.png').convert()
        self.image = pygame.transform.scale(self.raw_image,(radius,radius))
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y
        self.image.set_colorkey((0,0,0))
        if priv:
            self.xspeed = -2
        else:
            self.xspeed = 2
        self.yspeed = random.choice([-2,-1.5,-1,1,1.5,2])
        self.left = left
        self.right = right
        self.running = True
        self.bool_left = False      # for trigger
        self.bool_right = False
        self.bool_left2 = False     # for relieve
        self.bool_right2 = False
    def bounce(self):
        global running
        b = round(10*math.sqrt(2))
        if self.xspeed > 0:
            if self.right.rotate_state == 1:
                if (self.screen_width-3*b < self.rect.centerx < self.screen_width) and (self.right.y < self.rect.centery < self.right.y+self.right.length):
                    temp = self.xspeed
                    self.xspeed = self.yspeed
                    self.yspeed = temp
                    hit = pygame.mixer.Sound('ball_hit.wav')
                    hit.play()
                    if self.bool_right:
                        self.xspeed *= 2
                        self.yspeed *= 2
                        self.bool_right = False
                        self.bool_right2 = True
                        smash = pygame.mixer.Sound('smash.wav')
                        smash.play()
                    if self.bool_left2:
                        self.xspeed *= 0.5
                        self.yspeed *= 0.5
                        self.bool_left2 = False

                    if self.right.smash_count < 5:
                        self.right.smash_count += 1
            elif self.right.rotate_state == -1:
                if (self.screen_width-3*b < self.rect.centerx < self.screen_width) and (self.right.y < self.rect.centery < self.right.y+self.right.length):
                    temp = self.xspeed
                    self.xspeed = -self.yspeed
                    self.yspeed = -temp
                    hit = pygame.mixer.Sound('ball_hit.wav')
                    hit.play()
                    if self.bool_right:
                        self.xspeed *= 2
                        self.yspeed *= 2
                        self.bool_right = False
                        self.bool_right2 = True
                        smash = pygame.mixer.Sound('smash.wav')
                        smash.play()
                    if self.bool_left2:
                        self.xspeed *= 0.5
                        self.yspeed *= 0.5
                        self.bool_left2 = False

                    if self.right.smash_count < 5:
                        self.right.smash_count += 1
            else:
                if self.rect.right >= self.screen_width-20:
                    if self.rect.centery > self.right.y and self.rect.centery < self.right.y+self.right.length:
                        self.xspeed = -self.xspeed
                        hit = pygame.mixer.Sound('ball_hit.wav')
                        hit.play()
                        if self.bool_right:
                            self.xspeed *= 2
                            self.yspeed *= 2
                            self.bool_right = False
                            self.bool_right2 = True
                            smash = pygame.mixer.Sound('smash.wav')
                            smash.play()
                        if self.bool_left2:
                            self.xspeed *= 0.5
                            self.yspeed *= 0.5
                            self.bool_left2 = False

                        if self.right.smash_count < 5:
                            self.right.smash_count += 1
                    if self.rect.right >= self.screen_width:
                        self.running = False
                        return 1
        if self.xspeed < 0:
            if self.left.rotate_state == 1:
                if (0 < self.rect.centerx < 3*b) and (self.left.y < self.rect.centery < self.left.y+self.left.length):
                    temp = self.xspeed
                    self.xspeed = self.yspeed
                    self.yspeed = temp
                    hit = pygame.mixer.Sound('ball_hit.wav')
                    hit.play()
                    if self.bool_left:
                        self.xspeed *= 2
                        self.yspeed *= 2
                        self.bool_left = False
                        self.bool_left2 = True
                        smash = pygame.mixer.Sound('smash.wav')
                        smash.play()
                    if self.bool_right2:
                        self.xspeed *= 0.5
                        self.yspeed *= 0.5
                        self.bool_right2 = False

                    if self.left.smash_count < 5:
                        self.left.smash_count += 1
            elif self.left.rotate_state == -1:
                if (0 < self.rect.centerx < 3*b) and (self.left.y < self.rect.centery < self.left.y+self.left.length):
                    temp = self.xspeed
                    self.xspeed = -self.yspeed
                    self.yspeed = -temp
                    hit = pygame.mixer.Sound('ball_hit.wav')
                    hit.play()
                    if self.bool_left:
                        self.xspeed *= 2
                        self.yspeed *= 2
                        self.bool_left = False
                        self.bool_left2 = True
                        smash = pygame.mixer.Sound('smash.wav')
                        smash.play()
                    if self.bool_right2:
                        self.xspeed *= 0.5
                        self.yspeed *= 0.5
                        self.bool_right2 = False

                    if self.left.smash_count < 5:
                        self.left.smash_count += 1
            else:
                if self.rect.left <= 20:
                    if self.rect.centery > self.left.y and self.rect.centery < self.left.y+self.left.length:
                        self.xspeed = -self.xspeed
                        hit = pygame.mixer.Sound('ball_hit.wav')
                        hit.play()
                        if self.bool_left:
                            self.xspeed *= 2
                            self.yspeed *= 2
                            self.bool_left = False
                            self.bool_left2 = True
                            smash = pygame.mixer.Sound('smash.wav')
                            smash.play()
                        if self.bool_right2:
                            self.xspeed *= 0.5
                            self.yspeed *= 0.5
                            self.bool_right2 = False

                        if self.left.smash_count < 5:
                            self.left.smash_count += 1
                    if self.rect.left <= 0:
                        self.running = False
                        return 0
        if self.rect.bottom >= self.screen_height or self.rect.top <= 0:
            self.yspeed = - self.yspeed
    def update(self):
        self.rect.move_ip(self.xspeed,self.yspeed) #移動 method -- move_ip()
        a = self.bounce() # 碰邊則反彈
        self.screen.blit(self.image,self.rect) #重畫
        return a

class Plate:
    def __init__(self,screen,x,right):
        global j
        self.length = 120
        self.raw_image = pygame.image.load('./plate.png').convert()
        self.image = pygame.transform.scale(self.raw_image,(20,self.length))
        self.r_ro = pygame.image.load('./r_plate.png').convert()
        self.rimage = pygame.transform.scale(self.r_ro,(j,j))
        self.rrect = self.rimage.get_rect()
        self.l_ro = pygame.image.load('./l_plate.png').convert()
        self.limage = pygame.transform.scale(self.l_ro,(j,j))
        self.lrect = self.limage.get_rect()
        self.rotate_state = 0
        self.x = x
        self.y = 240
        self.screen = screen
        self.right = right
        self.speed = 5
        self.smash_count = 0
    def update(self):
        global j
        if self.right == True:
            a = pygame.K_UP
            b = pygame.K_DOWN
        else:
            a = pygame.K_w
            b = pygame.K_s
        keys = pygame.key.get_pressed()
        if keys[a]:
            self.y += -self.speed
        if keys[b]:
            self.y += self.speed
        if self.y > (600-self.length):
            self.y = (600-self.length)
        if self.y < 0:
            self.y = 0
        if self.rotate_state < -1:
            self.rotate_state = -1
        if self.rotate_state > 1:
            self.rotate_state = 1
        if self.rotate_state == 0:
            self.screen.blit(self.image,(self.x,self.y))
        if self.rotate_state == 1:
            self.screen.blit(self.limage,(self.x-j//2,self.y))
        if self.rotate_state == -1:
            self.screen.blit(self.rimage,(self.x-j//2,self.y))
class Treasure:
    def __init__(self,raw_image,x,y,screen,ball,index):
        self.image = pygame.transform.scale(raw_image,(80,80))
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y
        self.ball = ball
        self.screen = screen
        self.index = index
    def update(self):
        self.screen.blit(self.image,self.rect)
        if (self.rect.top-40 < self.ball.rect.top < self.rect.bottom) and (self.rect.left < self.ball.rect.right < self.rect.right+40):
            return True, self.index
        else:
            return False, -1
def texts(text,font,color):
    textSurface = font.render(text,True,color)
    return textSurface, textSurface.get_rect()
class button:
    def __init__(self,msg,x,y,w,h,ac,cc,tc,data,screen):
        self.mouse = pygame.mouse.get_pos()
        self.click = pygame.mouse.get_pressed()
        self.msg = msg
        self.tc = tc   # 字的顏色
        self.butfont = pygame.font.SysFont(None,55)
        self.textSurf, self.textRect = texts(self.msg,self.butfont,self.tc)
        self.textRect.center = ((x+w/2),(y+h/2))
        self.ac = ac   # 按鈕顏色
        self.cc = cc   # 游標移到按鈕時的顏色 
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.screen = screen
        self.data = data

    def blit(self):
        if self.x+self.w > self.mouse[0] > self.x and self.y+self.h > self.mouse[1] > self.y:
            pygame.draw.rect(self.screen,self.cc,(self.x,self.y,self.w,self.h))
        else:
            pygame.draw.rect(self.screen,self.ac,(self.x,self.y,self.w,self.h))
        #self.textSurf, self.textRect = texts(self.msg,self.butfont,self.tc)
        self.textRect.center = ( (self.x+self.w/2),(self.y+self.h/2))
        self.screen.blit(self.textSurf,self.textRect)
    def function(self):
        if self.x+self.w > self.mouse[0] > self.x and self.y+self.h > self.mouse[1] > self.y:
            for event in pygame.event.get():
                if event.type == MOUSEBUTTONDOWN:
                    but_press = pygame.mixer.Sound('button_press.wav')
                    but_press.play()
                    exec(open(self.data).read())
