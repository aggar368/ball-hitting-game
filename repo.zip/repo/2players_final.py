import pygame
from pygame.locals import *
import random, math, time

condition = False
g = False
i = 0
ball_list = []
running = True
flag = False
right_points = 0
left_points = 0
last_round = 0

def main():
    pygame.init()
    from all_class_final import Ball_twoplayers, Plate, Treasure
    global running , ball_list , i , flag , right_points , left_points, last_round
    running = True    # for each time we start main()
    treasure_storage = []
    width,height = 800,600
    screen = pygame.display.set_mode((width,height))
    image0 = pygame.image.load('./cat.png').convert()
    image1 = pygame.image.load('./faster.jpg').convert()
    image2 = pygame.image.load('./prolong.png').convert()
    treasure_list = [image0,image1,image2]
    trap_storage = []
    trap_image = pygame.transform.scale(treasure_list[0],(300,300))
    s0 = pygame.image.load('./0.png').convert()
    s1 = pygame.image.load('./1.png').convert()
    s2 = pygame.image.load('./2.png').convert()
    s3 = pygame.image.load('./3.png').convert()
    s4 = pygame.image.load('./4.png').convert()
    s5 = pygame.image.load('./5.png').convert()
    s0 = pygame.transform.scale(s0,(150,20))
    s1 = pygame.transform.scale(s1,(150,20))
    s2 = pygame.transform.scale(s2,(150,20))
    s3 = pygame.transform.scale(s3,(150,20))
    s4 = pygame.transform.scale(s4,(150,20))
    s5 = pygame.transform.scale(s5,(150,20))
    pump_list = [s0,s1,s2,s3,s4,s5]
    pygame.display.set_caption("dual mode")
    plateimage = pygame.image.load('./plate.png').convert()
    plateimage = pygame.transform.scale(plateimage,(20,120))

    right = Plate(screen,780,True)
    left = Plate(screen,0,False)
    ball1 = Ball_twoplayers(40,width//2,height//2,screen,left,right,last_round)
    ball_list.append(ball1)

    clock = pygame.time.Clock()
    start_font = pygame.font.SysFont(None,40)
    text_surface = start_font.render('Press SPACE to start',True,(0,255,0))
    l_scoreboard = pygame.font.SysFont(None,100)
    r_scoreboard = pygame.font.SysFont(None,100)
    l_surface = l_scoreboard.render(str(left_points),True,(0,0,0))
    r_surface = r_scoreboard.render(str(right_points),True,(0,0,0))
    screen.fill((255,255,255))
    screen.blit(text_surface,(260,0))
    screen.blit(l_surface,(200,70))
    screen.blit(r_surface,(560,70))
    screen.blit(ball_list[0].image,ball_list[0].rect)
    screen.blit(right.image,(right.x,right.y))
    screen.blit(left.image,(left.x,left.y))
    pygame.display.update()

    while True:
        ev = pygame.event.poll()
        if ev.type == QUIT:
            ball_list[0].running = False
            flag = True
        if ev.type == KEYDOWN:
            if ev.key == K_ESCAPE:
                ball_list[0].running = False
                flag = True
            if ev.key == K_SPACE:
                time0 = time.time()
                while ball_list[0].running:
                    clock.tick(60)

                    time1 = time.time()
                    if len(treasure_storage) == 0 and int(time1 - time0) == 20:
                        pic = random.choice(treasure_list)
                        ind = treasure_list.index(pic)
                        randx = random.randint(20,700)
                        randy = random.randint(0,520)
                        trea = Treasure(pic,randx,randy,screen,ball_list[0],ind)
                        treasure_storage.append(trea)
                    if int(time1 - time0) == 10:
                        left.length = 120
                        left.image = pygame.transform.scale(left.raw_image,(20,left.length))
                        right.length = 120
                        right.image = pygame.transform.scale(right.raw_image,(20,right.length))
                        if len(trap_storage) != 0:
                            trap_storage.pop(0)

                    for event in pygame.event.get():
                        if event.type == QUIT :
                            ball_list[0].running = False
                            flag = True
                        if event.type == KEYDOWN:
                            if event.key == K_ESCAPE:
                                ball_list[0].running = False
                                flag = True
                            if event.key == K_LEFT:
                                right.rotate_state += 1
                            if event.key == K_RIGHT:
                                right.rotate_state -= 1
                            if event.key == K_a:
                                left.rotate_state += 1
                            if event.key == K_d:
                                left.rotate_state -= 1

                            if event.key == K_m:
                                if right.smash_count >= 5:
                                    right.smash_count -= 5
                                    ball_list[0].bool_right = True
                            if event.key == K_x:
                                if left.smash_count >= 5:
                                    left.smash_count -= 5
                                    ball_list[0].bool_left = True

                    if ball_list[0].xspeed**2 + ball_list[0].yspeed**2 < 81:
                        ball_list[0].xspeed += math.log(1.00025)*ball_list[0].xspeed
                        ball_list[0].yspeed += math.log(1.00025)*ball_list[0].yspeed


                    screen.fill((255,255,255))
                    right.update()
                    left.update()
                    re = ball_list[0].update()
                    if re == 1:
                        left_points += 1
                        last_round = 1
                    if re == 0:
                        right_points += 1
                        last_round = 0

                    if len(treasure_storage) != 0:
                        eaten, which = treasure_storage[0].update()
                        if eaten == True:
                            time.sleep(0.1)
                            treasure_storage.pop(0)
                            sound = pygame.mixer.Sound('treasure_hit.wav')
                            sound.play()
                            time0 = time.time()
                            if which == 0:
                                trap_storage.append(trap_image)
                                if ball_list[0].xspeed > 0:
                                    side = 1
                                else:
                                    side = 0
                            if which == 1:
                                if ball_list[0].xspeed > 0 and left.speed < 15:
                                    left.speed += 5
                                if ball_list[0].xspeed < 0 and right.speed < 15:
                                    right.speed += 5
                            if which == 2:
                                if ball_list[0].xspeed > 0:
                                    left.length = 180
                                    left.image = pygame.transform.scale(left.raw_image,(20,left.length))
                                if ball_list[0].xspeed < 0:
                                    right.length = 180
                                    right.image = pygame.transform.scale(right.raw_image,(20,right.length))

                    if len(trap_storage) != 0:
                        if side:
                            screen.blit(trap_storage[0],(0,150))
                        else:
                            screen.blit(trap_storage[0],(400,150))

                    El = left.smash_count
                    Er = right.smash_count
                    bar_l = pump_list[El]
                    bar_r = pump_list[Er]
                    screen.blit(bar_l,(0,0))
                    screen.blit(bar_r,(650,0))

                    pygame.display.update()
        if ball_list[0].running == False:
            break
    ball_list.pop(0)
    pygame.quit()

while i < 7:
    pygame.init()
    pygame.mixer.music.load("game_mode.mp3")
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play(-1, 0)
    main()
    if right_points == 4:
        g = True
        string = 'right'
        condition = True
        break
    if left_points == 4:
        g = False
        string = 'left'
        condition = True
        break
    if flag:
        break
    i += 1


if condition:
    pygame.init()
    screen = pygame.display.set_mode((800,600))
    pygame.display.set_caption('result')
    end_font = pygame.font.SysFont(None,60)
    end_surface = end_font.render('The winner is player on '+string+' side!!',True,(255,200,0))
    screen.fill((255,255,255))
    screen.blit(end_surface,(50,250))
    pygame.display.update()
    time.sleep(5)
    pygame.quit()
exec(open('Menu_final.py').read())
