import pygame
from pygame.locals import *
import math
import time 
pygame.init()
from all_class_final import button
pygame.init()
pygame.mixer.music.load("menu_background.mp3")
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(-1, 0)
Menu = True
while Menu:
    screen = pygame.display.set_mode((800,600))
    pygame.display.set_caption("Ball-Hitting-Game!!!")
    screen.fill((0,0,0))
    bg = pygame.image.load('menu_title.png').convert()
    screen.blit(bg,(-30,40))
    b = button('2players',310,450,180,80,(255,255,255),(255,255,0),(0,0,0),'2players_final.py',screen)
    b.blit()
    b.function()
    a = button('1player',310,270,180,80,(255,255,255),(255,255,0),(0,0,0),'1player_final.py',screen)
    a.blit()
    a.function()
    pygame.display.update()
    for event in pygame.event.get():
        if event.type == QUIT:
            Menu = False
pygame.quit()
