import pygame
from pygame.locals import *
import random, math, time
highest_score = 0
i = 0
running = True
looping = True
pygame.init()
pygame.mixer.music.load("game_mode.mp3")
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(-1, 0)

def main():
    from all_class_final import Ball_oneplayer, Plate, Treasure
    global running , i , looping, highest_score
    running = True    # for each time we start main()

    my_points = 0
    treasure_storage = []
    width,height = 800,600
    screen = pygame.display.set_mode((width,height))
    image0 = pygame.image.load('./plus.png').convert()
    image1 = pygame.image.load('./faster.jpg').convert()
    image2 = pygame.image.load('./prolong.png').convert()
    image3 = pygame.image.load('./minus.png').convert()
    treasure_list = [image0,image1,image2,image3]
    pygame.display.set_caption("single mode")
    plateimage = pygame.image.load('./plate.png').convert()
    plateimage = pygame.transform.scale(plateimage,(20,120))
    right = Plate(screen,780,True)
    ball1 = Ball_oneplayer(40,width//2,height//2,screen,right,True)

    clock = pygame.time.Clock()
    start_font = pygame.font.SysFont(None,40)
    text_surface = start_font.render('Press SPACE to start',True,(0,255,0))
    my_scoreboard = pygame.font.SysFont(None,100)
    my_surface = my_scoreboard.render(str(my_points),True,(0,0,0))
    score_font = pygame.font.SysFont(None,40)
    highest_surface = score_font.render('highest score: '+str(highest_score),True,(255,200,0))
    screen.fill((255,255,255))
    screen.blit(text_surface,(260,10))
    screen.blit(highest_surface,(260,50))
    screen.blit(my_surface,(0,0))
    screen.blit(ball1.image,ball1.rect)
    screen.blit(right.image,(right.x,right.y))
    pygame.display.update()
    while True:
        bg = pygame.image.load('mode_background.jpg').convert()
        bg = pygame.transform.scale(bg,(800,600))
        screen.blit(bg,(0,0))
        ev = pygame.event.poll()
        if ev.type == QUIT:
            looping = False
            ball1.running = False
        if ev.type == KEYDOWN:
            if ev.key == K_ESCAPE:
                looping = False
                ball1.running = False
            if ev.key == K_SPACE:
                time0 = time.time()
                while ball1.running:
                    clock.tick(60)

                    time1 = time.time()
                    if int(time1 - time0) == 10:
                        if len(treasure_storage) != 0:
                            treasure_storage.pop(0)

                        pic = random.choice(treasure_list)
                        ind = treasure_list.index(pic)
                        randx = random.randint(20,700)
                        randy = random.randint(0,520)
                        trea = Treasure(pic,randx,randy,screen,ball1,ind)
                        treasure_storage.append(trea)

                        right.length = 120
                        right.image = pygame.transform.scale(right.raw_image,(20,right.length))

                        time0 = time.time()

                    for event in pygame.event.get():
                        if event.type == QUIT :
                            ball1.running = False
                            looping = False
                        if event.type == KEYDOWN:
                            if event.key == K_ESCAPE:
                                ball1.running = False
                                looping = False
                            if event.key == K_LEFT:
                                right.rotate_state += 1
                            if event.key == K_RIGHT:
                                right.rotate_state -= 1

                    if ball1.xspeed**2 + ball1.yspeed**2 < 100:
                        ball1.xspeed += math.log(1.0005)*ball1.xspeed
                        ball1.yspeed += math.log(1.0005)*ball1.yspeed

                    screen.fill((255,255,255))
                    right.update()
                    re = ball1.update()
                    if re == 2:
                        speed = (ball1.xspeed**2 + ball1.yspeed**2)**0.5
                        my_points += 10*int(speed)

                    my_surface = my_scoreboard.render(str(my_points),True,(0,0,0))
                    screen.blit(my_surface,(0,0))

                    if len(treasure_storage) != 0:
                        eaten, which = treasure_storage[0].update()
                        if eaten == True:
                            time.sleep(0.1)
                            treasure_storage.pop(0)
                            sound = pygame.mixer.Sound('treasure_hit.wav')
                            sound.play()                
                            time0 = time.time()
                            if which == 0:
                                my_points += 1000
                            if which == 1:
                                if right.speed < 15:
                                    right.speed += 5
                            if which == 2:
                                right.length = 180
                                right.image = pygame.transform.scale(right.raw_image,(20,right.length))
                            if which == 3:
                                my_points -= 500


                    pygame.display.update()
        if ball1.running == False:
            break
    if highest_score == 0 or my_points > highest_score:
        highest_score = my_points
    pygame.quit()

while looping:
    pygame.init()
    pygame.mixer.music.load("game_mode.mp3")
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play(-1, 0)
    main()
    pygame.quit()

pygame.init()
screen = pygame.display.set_mode((800,600))
pygame.display.set_caption('result')
end_font = pygame.font.SysFont(None,60)
end_surface = end_font.render('Your highest score is   '+str(highest_score)+'  !!',True,(255,200,0))
screen.fill((255,255,255))
screen.blit(end_surface,(100,250))
pygame.display.update()
time.sleep(5)
pygame.quit()

exec(open('Menu_final.py').read())